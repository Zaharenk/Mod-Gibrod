# VL Guard

Серверный античит для Minecraft 1.20.1 (Forge 47). Отдельный мод, ставится только на сервер.
Не наказывает способности Vampirism, Werewolves и Vampire Life. Подробности: [GUARD.md](GUARD.md).

Сборка: `gradle build` (JDK 17), jar в `build/libs/`.
