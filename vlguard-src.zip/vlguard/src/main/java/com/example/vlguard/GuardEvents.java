package com.example.vlguard;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityTeleportEvent;
import net.minecraftforge.event.entity.living.LivingKnockBackEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Все события античита. Каждый обработчик обёрнут в try/catch: ошибка в античите никогда не роняет сервер
 * и никого не наказывает.
 */
@Mod.EventBusSubscriber(modid = VlGuardMod.MODID)
public final class GuardEvents {
    private GuardEvents() {}

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        GuardCommand.register(e.getDispatcher());
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side.isClient() || !(e.player instanceof ServerPlayer p)) return;
        try {
            if (!GuardConfig.ENABLED.get()) return;
            int t = p.server.getTickCount();
            GuardData d = VlGuard.data(p.getUUID());
            if (GuardConfig.MOVEMENT.get()) GuardMovement.tick(p, d, t);
            if (t - d.lastDecay >= 20) {
                d.lastDecay = t;
                d.decay(GuardConfig.VL_DECAY.get());
            }
        } catch (Throwable ex) {
            GuardPunish.error(ex);
        }
    }

    // ---- вход, респавн, смена мира: позиция меняется сервером ----

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) VlGuard.data(p.getUUID()).start(p, p.server.getTickCount());
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) VlGuard.data(p.getUUID()).start(p, p.server.getTickCount());
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) VlGuard.data(p.getUUID()).start(p, p.server.getTickCount());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) VlGuard.DATA.remove(p.getUUID());
    }

    // ---- законные причины необычного движения ----

    @SubscribeEvent
    public static void onTeleport(EntityTeleportEvent e) {         // жемчуг Края, плод хоруса, /tp
        try {
            VlGuard.exempt(e.getEntity(), 40, "телепорт");
        } catch (Throwable ex) {
            GuardPunish.error(ex);
        }
    }

    @SubscribeEvent
    public static void onKnockBack(LivingKnockBackEvent e) {
        try {
            VlGuard.exempt(e.getEntity(), GuardConfig.KNOCKBACK_GRACE_TICKS.get(), "отбрасывание");
        } catch (Throwable ex) {
            GuardPunish.error(ex);
        }
    }

    @SubscribeEvent
    public static void onExplosion(ExplosionEvent.Detonate e) {
        try {
            for (Entity en : e.getAffectedEntities()) VlGuard.exempt(en, GuardConfig.KNOCKBACK_GRACE_TICKS.get() + 20, "взрыв");
        } catch (Throwable ex) {
            GuardPunish.error(ex);
        }
    }

    // ---- бой и блоки ----

    @SubscribeEvent
    public static void onAttack(AttackEntityEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        try {
            GuardCombat.attack(p, e.getTarget(), e);
        } catch (Throwable ex) {
            GuardPunish.error(ex);
        }
    }

    @SubscribeEvent
    public static void onUseBlock(PlayerInteractEvent.RightClickBlock e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        try {
            GuardCombat.block(p, e.getPos(), e);
        } catch (Throwable ex) {
            GuardPunish.error(ex);
        }
    }

    @SubscribeEvent
    public static void onBreakBlock(BlockEvent.BreakEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayer p)) return;
        try {
            GuardCombat.block(p, e.getPos(), e);
        } catch (Throwable ex) {
            GuardPunish.error(ex);
        }
    }
}
