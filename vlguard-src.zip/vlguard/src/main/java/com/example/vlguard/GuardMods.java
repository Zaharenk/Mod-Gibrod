package com.example.vlguard;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

/** Состояния способностей других модов, которые разрешают необычное движение. */
final class GuardMods {
    /** true, если на сервере есть Vampirism. Выставляется при загрузке мода. */
    static boolean vampirism;

    private GuardMods() {}

    static boolean batActive(Player p) {
        return vampirism && VampirismHook.batActive(p);
    }

    /**
     * Метки способностей любого мода, которые хранят время перезарядки в данных игрока (формат записи
     * в конфиге: ключ|перезарядка|окно в тиках). По ним видно, что способность использована только что.
     * По умолчанию описан рывок из Vampire Life.
     */
    static boolean abilityMarkerActive(ServerPlayer p) {
        long now = p.level().getGameTime();
        for (String s : GuardConfig.ABILITY_MARKERS.get()) {
            String[] a = s.split("\\|");
            if (a.length != 3) continue;
            try {
                long cooldown = Long.parseLong(a[1].trim());
                long grace = Long.parseLong(a[2].trim());
                long ready = p.getPersistentData().getLong(a[0].trim());
                long used = ready - cooldown;
                if (ready > now && now >= used && now - used <= grace) return true;
            } catch (NumberFormatException ignored) {
                // неверная строка в конфиге пропускается
            }
        }
        return false;
    }
}
