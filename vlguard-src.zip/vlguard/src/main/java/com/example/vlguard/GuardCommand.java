package com.example.vlguard;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/** /vlguard (права 3): status, vl, reset, exempt, alerts. */
final class GuardCommand {
    private GuardCommand() {}

    static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("vlguard").requires(s -> s.hasPermission(3))
                .then(Commands.literal("status").executes(c -> status(c.getSource())))
                .then(Commands.literal("alerts").executes(c -> alerts(c.getSource())))
                .then(Commands.literal("vl").then(Commands.argument("player", EntityArgument.player())
                        .executes(c -> vl(c.getSource(), EntityArgument.getPlayer(c, "player")))))
                .then(Commands.literal("reset").then(Commands.argument("player", EntityArgument.player())
                        .executes(c -> reset(c.getSource(), EntityArgument.getPlayer(c, "player")))))
                .then(Commands.literal("exempt").then(Commands.argument("player", EntityArgument.player())
                        .then(Commands.argument("seconds", IntegerArgumentType.integer(1, 3600))
                                .executes(c -> exempt(c.getSource(), EntityArgument.getPlayer(c, "player"),
                                        IntegerArgumentType.getInteger(c, "seconds")))))));
    }

    private static int say(CommandSourceStack s, String text) {
        s.sendSuccess(() -> Component.literal(text), false);
        return 1;
    }

    private static int status(CommandSourceStack s) {
        return say(s, "VL Guard: " + (GuardConfig.ENABLED.get() ? "включён" : "выключен")
                + ". Движение: " + GuardConfig.MOVEMENT.get() + ", бой: " + GuardConfig.COMBAT.get()
                + ", блоки: " + GuardConfig.BLOCKS.get() + ". Откат: " + GuardConfig.SETBACK.get()
                + ", кик: " + GuardConfig.KICK.get() + ", бан: " + GuardConfig.BAN.get()
                + ". Окно после способности: " + GuardConfig.ABILITY_GRACE_TICKS.get() + " тиков. Отслеживается игроков: " + VlGuard.DATA.size());
    }

    private static int alerts(CommandSourceStack s) {
        ServerPlayer p = s.getPlayer();
        if (p == null) return say(s, "Команда только для игрока.");
        boolean muted = VlGuard.MUTED.add(p.getUUID());
        if (!muted) VlGuard.MUTED.remove(p.getUUID());
        return say(s, muted ? "Оповещения VL Guard выключены для вас." : "Оповещения VL Guard включены для вас.");
    }

    private static int vl(CommandSourceStack s, ServerPlayer p) {
        GuardData d = VlGuard.data(p.getUUID());
        StringBuilder sb = new StringBuilder("VL " + p.getGameProfile().getName() + ":");
        for (GuardCheck c : GuardCheck.values()) sb.append(' ').append(c.title).append('=').append(GuardPunish.f("%.1f", d.vl[c.ordinal()]));
        int now = p.server.getTickCount();
        sb.append(". Исключение: ").append(now < d.graceUntil ? d.graceWhy + " (ещё " + (d.graceUntil - now) + " тиков)" : "нет");
        return say(s, sb.toString());
    }

    private static int reset(CommandSourceStack s, ServerPlayer p) {
        GuardData d = VlGuard.data(p.getUUID());
        java.util.Arrays.fill(d.vl, 0.0);
        return say(s, "VL игрока " + p.getGameProfile().getName() + " сброшен.");
    }

    private static int exempt(CommandSourceStack s, ServerPlayer p, int seconds) {
        VlGuard.exempt(p, seconds * 20, "команда /vlguard");
        return say(s, p.getGameProfile().getName() + " не проверяется " + seconds + " с.");
    }
}
