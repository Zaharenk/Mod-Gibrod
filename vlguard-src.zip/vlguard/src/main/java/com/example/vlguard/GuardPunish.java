package com.example.vlguard;

import com.mojang.logging.LogUtils;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.UserBanListEntry;
import org.slf4j.Logger;

import java.util.Locale;

/** Учёт нарушений (VL) и наказания. Любое наказание пропускается, если у игрока действует исключение. */
final class GuardPunish {
    private static final Logger LOG = LogUtils.getLogger();
    private static boolean errorLogged;

    private GuardPunish() {}

    static String f(String fmt, Object... a) {
        return String.format(Locale.ROOT, fmt, a);
    }

    static void error(Throwable ex) {
        if (errorLogged) return;
        errorLogged = true;
        LOG.error("VL Guard: внутренняя ошибка проверки, игроки не наказываются. Сообщите разработчику.", ex);
    }

    /**
     * Записать нарушение.
     * @param back куда откатить игрока (null: откат не нужен)
     */
    static void flag(ServerPlayer p, GuardData d, int t, GuardCheck c, double weight, String info, double[] back) {
        if (!GuardConfig.ENABLED.get()) return;
        if (GuardConfig.EXEMPT_OPS.get() && p.createCommandSourceStack().hasPermission(2)) return;
        // способность (Vampirism, Werewolves, аддоны): никаких нарушений, что бы ни увидела проверка
        if (t < d.graceUntil || GuardMods.batActive(p) || GuardMods.abilityMarkerActive(p)) return;

        int i = c.ordinal();
        d.vl[i] += weight;
        double v = d.vl[i];

        if (v >= GuardConfig.ALERT_VL.get() && t - d.lastAlert[i] >= 100) {
            d.lastAlert[i] = t;
            alert(p, c, v, info);
        }
        if (c.movement && back != null && GuardConfig.SETBACK.get() && v >= GuardConfig.SETBACK_VL.get()) setback(p, d, t, back);
        if (GuardConfig.KICK.get() && v >= GuardConfig.KICK_VL.get()) kick(p, c, v);
        if (GuardConfig.BAN.get() && v >= GuardConfig.BAN_VL.get()) ban(p, c, v);
    }

    private static void alert(ServerPlayer p, GuardCheck c, double vl, String info) {
        String name = p.getGameProfile().getName();
        Component msg = Component.literal("[VL Guard] ").withStyle(ChatFormatting.RED)
                .append(Component.literal(name + ": " + c.title + ", VL " + f("%.1f", vl) + ". " + info).withStyle(ChatFormatting.GRAY));
        LOG.warn("[VL Guard] {}: {}, VL {}. {}", name, c.title, f("%.1f", vl), info);
        if (!GuardConfig.ALERTS.get()) return;
        for (ServerPlayer o : p.server.getPlayerList().getPlayers()) {
            if (o.createCommandSourceStack().hasPermission(2) && !VlGuard.MUTED.contains(o.getUUID())) o.sendSystemMessage(msg);
        }
    }

    private static void setback(ServerPlayer p, GuardData d, int t, double[] to) {
        if (t - d.lastSetback < 20) return;
        d.lastSetback = t;
        p.connection.teleport(to[0], to[1], to[2], p.getYRot(), p.getXRot());
        d.x = to[0]; d.y = to[1]; d.z = to[2];
        d.grace(t, 20, "откат позиции");
        d.clear();
        d.air = 0;
        d.hover = 0;
    }

    private static void kick(ServerPlayer p, GuardCheck c, double vl) {
        LOG.warn("[VL Guard] кик {}: {} VL {}", p.getGameProfile().getName(), c.title, f("%.1f", vl));
        p.connection.disconnect(Component.literal("VL Guard: подозрение на читы (" + c.title + ")"));
    }

    private static void ban(ServerPlayer p, GuardCheck c, double vl) {
        String reason = "VL Guard: подозрение на читы (" + c.title + ", VL " + f("%.0f", vl) + ")";
        LOG.warn("[VL Guard] БАН {}: {}", p.getGameProfile().getName(), reason);
        p.server.getPlayerList().getBans().add(new UserBanListEntry(p.getGameProfile(), null, "VL Guard", null, reason));
        p.connection.disconnect(Component.literal(reason));
    }
}
