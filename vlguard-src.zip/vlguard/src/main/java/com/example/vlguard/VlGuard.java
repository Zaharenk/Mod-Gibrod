package com.example.vlguard;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * VL Guard: самостоятельный серверный античит (игрокам ставить ничего не нужно).
 *
 * Принцип: античит не знает «лимитов Minecraft», он читает ТЕ ЖЕ значения, которые меняют способности мода:
 *  - допустимая скорость берётся из живого атрибута MOVEMENT_SPEED (Powers, Мастерство, эффекты, форма оборотня);
 *  - высота прыжка считается по живой гравитации ENTITY_GRAVITY (у вампира она ниже) и эффекту прыжка;
 *  - дальность удара и взаимодействия берётся из атрибутов ENTITY_REACH и BLOCK_REACH;
 *  - полёт летучей мыши разрешён самим Vampirism (Abilities.mayfly), античит это уважает;
 *  - любое действие Vampirism и Werewolves (событие ActionActivatedEvent) даёт короткое окно без проверок движения;
 *  - рывок, отброс затмения, телепорт замка и дуэли явно просят исключение через {@link #exempt}.
 * Ничего не наказывается автоматически без настройки: по умолчанию только предупреждения операторам и откат позиции.
 */
public final class VlGuard {
    static final Map<UUID, GuardData> DATA = new ConcurrentHashMap<>();
    static final Set<UUID> MUTED = ConcurrentHashMap.newKeySet();

    private VlGuard() {}

    static GuardData data(UUID id) {
        return DATA.computeIfAbsent(id, k -> new GuardData());
    }

    /**
     * Публичный API: не проверять движение игрока в течение {@code ticks} тиков (20 тиков = 1 с).
     * Вызывайте перед тем, как код мода двигает игрока (телепорт, импульс, рывок). Безопасно для любых сущностей.
     */
    public static void exempt(Entity e, int ticks, String reason) {
        if (e instanceof ServerPlayer sp) data(sp.getUUID()).grace(sp.server.getTickCount(), ticks, reason);
    }
}
