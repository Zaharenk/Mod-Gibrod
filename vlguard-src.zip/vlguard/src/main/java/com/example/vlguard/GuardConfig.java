package com.example.vlguard;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig;

/** Настройки античита. Файл: config/vlguard.toml (правится без пересборки). */
public final class GuardConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue ENABLED, MOVEMENT, COMBAT, BLOCKS, EXEMPT_OPS,
            ALERTS, CANCEL_ILLEGAL, SETBACK, KICK, BAN;
    public static final ForgeConfigSpec.DoubleValue SPEED_TOLERANCE, REACH_MARGIN, BLOCK_MARGIN,
            ALERT_VL, SETBACK_VL, KICK_VL, BAN_VL, VL_DECAY;
    public static final ForgeConfigSpec.ConfigValue<java.util.List<? extends String>> ABILITY_MARKERS;
    public static final ForgeConfigSpec.IntValue ABILITY_GRACE_TICKS, KNOCKBACK_GRACE_TICKS, MAX_ATTACKS_PER_SECOND;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.comment("VL Guard: серверный античит. Способности Vampirism, Werewolves и модов на их основе (например Vampire Life) он не наказывает.")
                .push("general");
        ENABLED = b.comment("Включить античит").define("enabled", true);
        MOVEMENT = b.comment("Проверять скорость, полёт и высоту прыжка").define("checkMovement", true);
        COMBAT = b.comment("Проверять дальность удара, автокликер и удары по нескольким целям").define("checkCombat", true);
        BLOCKS = b.comment("Проверять дальность взаимодействия с блоками").define("checkBlockReach", true);
        EXEMPT_OPS = b.comment("Не проверять операторов (права 2 и выше)").define("exemptOperators", true);
        b.pop();

        b.comment("Допуски. Чем больше число, тем меньше ложных срабатываний и тем легче обойти проверку.").push("tolerance");
        SPEED_TOLERANCE = b.comment("Множитель допустимой скорости (1.15 = запас 15%)")
                .defineInRange("speedTolerance", 1.15, 1.0, 5.0);
        REACH_MARGIN = b.comment("Запас дальности удара в блоках (лаги, хитбоксы)")
                .defineInRange("reachMargin", 1.0, 0.0, 5.0);
        BLOCK_MARGIN = b.comment("Запас дальности до блока в блоках")
                .defineInRange("blockReachMargin", 1.6, 0.0, 6.0);
        MAX_ATTACKS_PER_SECOND = b.comment("Больше ударов за секунду считается автокликером")
                .defineInRange("maxAttacksPerSecond", 30, 5, 200);
        ABILITY_GRACE_TICKS = b.comment("Сколько тиков не проверять движение после активации способности (20 тиков = 1 с)")
                .defineInRange("abilityGraceTicks", 100, 0, 1200);
        KNOCKBACK_GRACE_TICKS = b.comment("Сколько тиков не проверять движение после отбрасывания, взрыва или рывка")
                .defineInRange("knockbackGraceTicks", 30, 0, 200);
        ABILITY_MARKERS = b.comment("Способности других модов, которые записывают время готовности в данные игрока.",
                        "Формат: ключ|перезарядка в тиках|сколько тиков после использования не проверять движение.",
                        "По умолчанию: рывок из Vampire Life (ключ vl_cd_shadow_dash_amulet).")
                .defineList("abilityMarkers", java.util.List.of("vl_cd_shadow_dash_amulet|80|60"), o -> o instanceof String);
        b.pop();

        b.comment("Наказания. Баны и кики по умолчанию ВЫКЛЮЧЕНЫ: эвристики античита могут ошибаться.").push("punishments");
        ALERTS = b.comment("Сообщать операторам о подозрениях").define("alertOperators", true);
        CANCEL_ILLEGAL = b.comment("Отменять явно невозможные удары и действия с блоками").define("cancelIllegalActions", true);
        SETBACK = b.comment("Возвращать игрока на безопасную позицию при нарушении движения").define("setback", true);
        KICK = b.comment("Выгонять с сервера при очень высоком VL").define("kick", false);
        BAN = b.comment("Банить при критическом VL (используется стандартный список банов)").define("autoBan", false);
        ALERT_VL = b.defineInRange("alertVl", 8.0, 1.0, 1000.0);
        SETBACK_VL = b.defineInRange("setbackVl", 12.0, 1.0, 1000.0);
        KICK_VL = b.defineInRange("kickVl", 60.0, 1.0, 1000.0);
        BAN_VL = b.defineInRange("banVl", 150.0, 1.0, 5000.0);
        VL_DECAY = b.comment("На сколько уровень нарушений (VL) падает каждую секунду")
                .defineInRange("vlDecayPerSecond", 1.0, 0.0, 100.0);
        b.pop();
        SPEC = b.build();
    }

    private GuardConfig() {}

    /** Вызывается из конструктора главного класса мода. */
    public static void register() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, SPEC, "vlguard.toml");
    }
}
