package com.example.vlguard;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ForgeMod;
import net.minecraftforge.eventbus.api.Event;

/**
 * Проверки боя и взаимодействия с блоками. Дальность берётся из живых атрибутов ENTITY_REACH и BLOCK_REACH,
 * поэтому формы и предметы, которые увеличивают дальность, считаются законными. Способности мода (укус, снаряды,
 * затмение, колья) не идут через событие удара игрока и проверкам не подвергаются.
 */
final class GuardCombat {
    private GuardCombat() {}

    private static boolean skip(ServerPlayer p) {
        return p.isCreative() || p.isSpectator() || !p.isAlive();
    }

    static void attack(ServerPlayer p, Entity target, Event ev) {
        if (!GuardConfig.ENABLED.get() || !GuardConfig.COMBAT.get() || skip(p)) return;
        int t = p.server.getTickCount();
        GuardData d = VlGuard.data(p.getUUID());

        // дальность: от глаз до ближайшей точки хитбокса цели
        Vec3 eye = p.getEyePosition();
        AABB bb = target.getBoundingBox();
        Vec3 near = new Vec3(Mth.clamp(eye.x, bb.minX, bb.maxX), Mth.clamp(eye.y, bb.minY, bb.maxY), Mth.clamp(eye.z, bb.minZ, bb.maxZ));
        double dist = eye.distanceTo(near);
        double lim = p.getAttributeValue(ForgeMod.ENTITY_REACH.get()) + GuardConfig.REACH_MARGIN.get();
        if (dist > lim) {
            GuardPunish.flag(p, d, t, GuardCheck.REACH, Math.min(5.0, 1.0 + (dist - lim) * 2.0),
                    GuardPunish.f("до цели %.2f, допустимо %.2f", dist, lim), null);
            if (dist > lim + 1.0 && GuardConfig.CANCEL_ILLEGAL.get() && t >= d.graceUntil) ev.setCanceled(true);
        }

        // частота ударов за последнюю секунду
        d.attacks.addLast(t);
        while (!d.attacks.isEmpty() && t - d.attacks.peekFirst() > 20) d.attacks.pollFirst();
        int max = GuardConfig.MAX_ATTACKS_PER_SECOND.get();
        if (d.attacks.size() > max) {
            GuardPunish.flag(p, d, t, GuardCheck.AUTOCLICK, 1.0, d.attacks.size() + " ударов за секунду, допустимо " + max, null);
        }

        // несколько разных целей в один тик
        if (d.targetsTick != t) {
            d.targetsTick = t;
            d.targets.clear();
        }
        d.targets.add(target.getId());
        if (d.targets.size() >= 3) {
            GuardPunish.flag(p, d, t, GuardCheck.MULTITARGET, 2.0, d.targets.size() + " разных целей за один тик", null);
            if (GuardConfig.CANCEL_ILLEGAL.get() && t >= d.graceUntil) ev.setCanceled(true);
        }
    }

    static void block(ServerPlayer p, BlockPos pos, Event ev) {
        if (!GuardConfig.ENABLED.get() || !GuardConfig.BLOCKS.get() || skip(p)) return;
        int t = p.server.getTickCount();
        GuardData d = VlGuard.data(p.getUUID());
        double dist = p.getEyePosition().distanceTo(Vec3.atCenterOf(pos));
        double lim = p.getAttributeValue(ForgeMod.BLOCK_REACH.get()) + GuardConfig.BLOCK_MARGIN.get();
        if (dist > lim) {
            GuardPunish.flag(p, d, t, GuardCheck.BLOCKREACH, Math.min(5.0, 1.0 + (dist - lim)),
                    GuardPunish.f("до блока %.2f, допустимо %.2f", dist, lim), null);
            if (dist > lim + 2.0 && GuardConfig.CANCEL_ILLEGAL.get()) ev.setCanceled(true);
        }
    }
}
