package com.example.vlguard;

/** Виды проверок VL Guard. movement = true: нарушение можно исправить откатом позиции. */
public enum GuardCheck {
    SPEED("Скорость", true),
    FLY("Полёт", true),
    HIGHJUMP("Высокий прыжок", true),
    REACH("Дальность удара", false),
    AUTOCLICK("Автокликер", false),
    MULTITARGET("Мульти-цель", false),
    BLOCKREACH("Дальность блоков", false);

    public final String title;
    public final boolean movement;

    GuardCheck(String title, boolean movement) {
        this.title = title;
        this.movement = movement;
    }
}
