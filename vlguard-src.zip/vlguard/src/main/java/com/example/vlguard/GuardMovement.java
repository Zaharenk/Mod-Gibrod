package com.example.vlguard;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SlimeBlock;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ForgeMod;

/**
 * Проверки движения. Все пределы считаются из ЖИВЫХ значений игрока, поэтому способности мода (скорость, низкая
 * гравитация, эффекты, формы оборотня) увеличивают допустимое автоматически, без списков исключений.
 * Телепорты (более 8 блоков за тик) сбрасывают проверку: клиентские телепорты отклоняет сам Minecraft.
 */
final class GuardMovement {
    private GuardMovement() {}

    static void tick(ServerPlayer p, GuardData d, int t) {
        double x = p.getX(), y = p.getY(), z = p.getZ();
        ResourceKey<Level> dim = p.level().dimension();
        if (!d.init || dim != d.dim) {
            d.start(p, t);
            return;
        }
        double ox = d.x, oy = d.y, oz = d.z;
        d.x = x; d.y = y; d.z = z;
        double dx = x - ox, dy = y - oy, dz = z - oz;
        double h = Math.sqrt(dx * dx + dz * dz);

        if (h > 8.0 || Math.abs(dy) > 8.0) {            // серверный телепорт (телепорт способности, команда, мод)
            d.grace(t, 40, "телепорт");
            d.clear();
            d.resetFlight(y);
            return;
        }
        String why = exemption(p, d, t);
        if (why != null || t < d.graceUntil) {
            d.clear();
            d.resetFlight(y);
            d.hasGround = true;
            d.groundX = x; d.groundZ = z;
            return;
        }

        boolean special = special(p);
        boolean solid = !p.level().noCollision(p, p.getBoundingBox().move(0.0, -0.08, 0.0));
        boolean grounded = solid || special;

        // ---- скорость: сумма за 20 тиков против допустимой, посчитанной из живого атрибута скорости ----
        if (special || (solid && frictionBelow(p) > 0.65f)) {   // вода, лёд и подобное
            if (!special) d.grace(t, 25, "скользкая поверхность");   // после льда игрок ещё скользит
            d.clear();
        } else {
            double attr = Math.max(0.05, p.getAttributeValue(Attributes.MOVEMENT_SPEED));
            d.push(h, attr * 2.16 * 1.30, ox, oy, oz);          // 2.16: предел ходьбы за тик; 1.30: прыжки на бегу
            speed(p, d, t);
        }

        // ---- полёт и высота прыжка ----
        if (grounded) {
            d.groundX = x; d.groundY = y; d.groundZ = z;
            d.hasGround = true;
            d.air = 0;
            d.hover = 0;
            d.bouncy = solid && bouncyBelow(p);
        } else {
            vertical(p, d, t, y, dy, h);
        }
    }

    /** Состояния, при которых проверки не нужны вообще. Возвращает причину или null. */
    private static String exemption(ServerPlayer p, GuardData d, int t) {
        if (p.isCreative() || p.isSpectator()) return "творчество или наблюдатель";
        var ab = p.getAbilities();
        if (ab.mayfly || ab.flying) return "разрешён полёт (форма летучей мыши, права)";
        if (p.isPassenger()) return "в транспорте";
        if (p.isFallFlying()) return "элитры";
        if (p.isAutoSpinAttack()) return "риптайд";
        if (p.isSleeping() || !p.isAlive()) return "сон или смерть";
        if (GuardMods.batActive(p)) return "форма летучей мыши";
        if (p.hurtMarked) {
            d.grace(t, GuardConfig.KNOCKBACK_GRACE_TICKS.get(), "импульс (отброс, рывок)");
            return "импульс";
        }
        // Сервер мог сбросить hurtMarked раньше проверки, поэтому смотрим и на сам импульс, и на метки способностей
        Vec3 dm = p.getDeltaMovement();
        if (dm.x * dm.x + dm.z * dm.z > 0.64 || dm.y > 0.9) {
            d.grace(t, GuardConfig.KNOCKBACK_GRACE_TICKS.get(), "сильный импульс скорости");
            return "импульс скорости";
        }
        if (GuardMods.abilityMarkerActive(p)) return "способность только что использована";
        if (p.hurtTime > 0) {
            d.grace(t, 15, "получение урона");
            return "урон";
        }
        if (p.hasEffect(MobEffects.LEVITATION)) return "левитация";
        return null;
    }

    private static boolean special(ServerPlayer p) {
        if (p.isInWaterOrBubble() || p.isInLava() || p.isSwimming() || p.onClimbable()) return true;
        Level lvl = p.level();
        BlockPos bp = p.blockPosition();
        return lvl.getBlockState(bp).is(Blocks.COBWEB) || lvl.getBlockState(bp.above()).is(Blocks.COBWEB)
                || lvl.getBlockState(bp).is(Blocks.SWEET_BERRY_BUSH) || lvl.getBlockState(bp).is(Blocks.POWDER_SNOW)
                || lvl.getBlockState(bp).is(Blocks.BUBBLE_COLUMN) || lvl.getBlockState(bp.below()).is(Blocks.HONEY_BLOCK);
    }

    private static float frictionBelow(ServerPlayer p) {
        Block b = p.level().getBlockState(p.blockPosition().below()).getBlock();
        return b.getFriction();
    }

    private static boolean bouncyBelow(ServerPlayer p) {
        Block b = p.level().getBlockState(p.blockPosition().below()).getBlock();
        return b instanceof SlimeBlock || b instanceof BedBlock;
    }

    private static void speed(ServerPlayer p, GuardData d, int t) {
        if (d.n < GuardData.WINDOW) return;
        double sum = d.sumH();
        double lim = d.sumAllow() * GuardConfig.SPEED_TOLERANCE.get() + 1.0;
        if (sum <= lim) return;
        double weight = Math.min(10.0, 1.0 + (sum / lim - 1.0) * 10.0);
        double[] back = d.oldest();
        d.clear();      // один скачок считается один раз, а не 20 тиков подряд
        GuardPunish.flag(p, d, t, GuardCheck.SPEED, weight,
                GuardPunish.f("%.1f блоков за 1 с, допустимо %.1f", sum, lim), back);
    }

    private static void vertical(ServerPlayer p, GuardData d, int t, double y, double dy, double h) {
        d.air++;
        if (!d.hasGround) return;
        double g = Math.max(0.005, p.getAttributeValue(ForgeMod.ENTITY_GRAVITY.get()));   // у вампиров ниже, прыжки выше
        double jump = 0.42;
        MobEffectInstance je = p.getEffect(MobEffects.JUMP);
        if (je != null) jump += 0.1 * (je.getAmplifier() + 1);
        double lim = apex(jump, g) * 1.15 + 1.0;
        double rise = y - d.groundY;
        double[] back = {d.groundX, d.groundY, d.groundZ};

        if (!d.bouncy && rise > lim) {
            d.groundY = y;      // считаем подъём заново, чтобы не засчитывать один подъём много раз
            GuardPunish.flag(p, d, t, GuardCheck.HIGHJUMP, Math.min(6.0, 1.0 + (rise - lim)),
                    GuardPunish.f("подъём %.2f, допустимо %.2f", rise, lim), back);
        }

        boolean slow = p.hasEffect(MobEffects.SLOW_FALLING) || g < 0.02;
        boolean notFalling = Math.abs(dy) < 0.04 || (d.air > 25 && dy > -0.12);
        if (!slow && d.air > 10 && h > 0.02 && notFalling) d.hover++; else d.hover = 0;
        if (d.hover >= 8) {
            d.hover = 0;
            GuardPunish.flag(p, d, t, GuardCheck.FLY, 2.0, "завис или планирует в воздухе при движении", back);
        }
    }

    /** Высота прыжка с учётом гравитации g и сопротивления воздуха (как в Minecraft: v = (v - g) * 0.98). */
    static double apex(double v, double g) {
        double h = 0;
        for (int i = 0; i < 400 && v > 0; i++) {
            h += v;
            v = (v - g) * 0.98;
        }
        return h;
    }
}
