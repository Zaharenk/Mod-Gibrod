package com.example.vlguard;

import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;

/**
 * VL Guard: самостоятельный серверный античит для Forge 1.20.1. Игрокам ставить не нужно.
 * Работает с любыми модами. Если на сервере есть Vampirism (и Werewolves, Vampire Life), их способности
 * распознаются и не наказываются: см. GUARD.md.
 */
@Mod(VlGuardMod.MODID)
public class VlGuardMod {
    public static final String MODID = "vlguard";

    public VlGuardMod() {
        GuardConfig.register();
        if (ModList.get().isLoaded("vampirism")) {
            GuardMods.vampirism = true;
            VampirismHook.init();   // отдельный класс: без Vampirism он не загружается
        }
    }
}
