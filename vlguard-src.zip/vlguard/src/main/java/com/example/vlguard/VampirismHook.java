package com.example.vlguard;

import de.teamlapen.vampirism.api.entity.player.actions.IActionHandler;
import de.teamlapen.vampirism.api.entity.player.actions.ILastingAction;
import de.teamlapen.vampirism.api.event.ActionEvent;
import de.teamlapen.vampirism.entity.player.vampire.VampirePlayer;
import de.teamlapen.vampirism.entity.player.vampire.actions.VampireActions;
import de.teamlapen.vampirism.util.RegUtil;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.EventPriority;

/** Связь с Vampirism и Werewolves (загружается только если Vampirism есть на сервере). */
final class VampirismHook {
    private VampirismHook() {}

    static void init() {
        MinecraftForge.EVENT_BUS.addListener(EventPriority.LOWEST, false, ActionEvent.ActionActivatedEvent.class, VampirismHook::onAbility);
    }

    /**
     * Любая способность Vampirism и Werewolves (и всех модов-аддонов, которые запускают её через их обработчик действий,
     * например способности гибрида Vampire Life) даёт короткое окно без проверок движения.
     * Событие приходит до самой способности, поэтому телепорт или импульс не засчитается как нарушение.
     */
    private static void onAbility(ActionEvent.ActionActivatedEvent e) {
        try {
            Player p = e.getFactionPlayer().getRepresentingPlayer();
            VlGuard.exempt(p, GuardConfig.ABILITY_GRACE_TICKS.get(), "способность " + RegUtil.id(e.getAction()).getPath());
        } catch (Throwable ex) {
            GuardPunish.error(ex);
        }
    }

    /** Форма летучей мыши включена (Vampirism сам выдаёт полёт через Abilities.mayfly, это страховка). */
    @SuppressWarnings({"unchecked", "rawtypes"})
    static boolean batActive(Player p) {
        try {
            VampirePlayer vp = VampirePlayer.getOpt(p).resolve().orElse(null);
            if (vp == null) return false;
            IActionHandler vh = vp.getActionHandler();
            Object bat = VampireActions.BAT.get();
            return bat instanceof ILastingAction la && vh.isActionActive(la);
        } catch (Throwable t) {
            return false;
        }
    }
}
