package com.example.vlguard;

import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;

/** Состояние античита для одного игрока (только в памяти сервера). */
final class GuardData {
    static final int WINDOW = 20;

    boolean init;
    ResourceKey<Level> dim;
    double x, y, z;                      // позиция в конце прошлого тика

    // окно скорости: пройденное по горизонтали и допустимое за последние 20 тиков
    final double[] win = new double[WINDOW], allow = new double[WINDOW];
    final double[] hx = new double[WINDOW], hy = new double[WINDOW], hz = new double[WINDOW];
    int n, pos;

    int graceUntil;                      // до этого тика сервера движение не проверяется
    String graceWhy = "";

    // полёт и прыжок
    double groundX, groundY, groundZ;
    boolean hasGround, bouncy;
    int air, hover;

    final double[] vl = new double[GuardCheck.values().length];
    final int[] lastAlert = new int[GuardCheck.values().length];
    int lastDecay, lastSetback = -1000;

    // бой
    final ArrayDeque<Integer> attacks = new ArrayDeque<>();
    int targetsTick = -1;
    final Set<Integer> targets = new HashSet<>();

    void grace(int t, int ticks, String why) {
        if (t + ticks > graceUntil) {
            graceUntil = t + ticks;
            graceWhy = why;
        }
    }

    void clear() {
        n = 0;
        pos = 0;
    }

    void push(double h, double a, double px, double py, double pz) {
        win[pos] = h; allow[pos] = a; hx[pos] = px; hy[pos] = py; hz[pos] = pz;
        pos = (pos + 1) % WINDOW;
        if (n < WINDOW) n++;
    }

    double sumH() { double s = 0; for (int i = 0; i < n; i++) s += win[i]; return s; }

    double sumAllow() { double s = 0; for (int i = 0; i < n; i++) s += allow[i]; return s; }

    /** Позиция 20 тиков назад (когда окно заполнено, это ячейка, которая будет перезаписана следующей). */
    double[] oldest() { return new double[]{hx[pos], hy[pos], hz[pos]}; }

    void resetFlight(double y) {
        groundY = y;
        air = 0;
        hover = 0;
    }

    void decay(double amount) {
        for (int i = 0; i < vl.length; i++) vl[i] = Math.max(0.0, vl[i] - amount);
    }

    void start(ServerPlayer p, int t) {
        init = true;
        dim = p.level().dimension();
        x = p.getX(); y = p.getY(); z = p.getZ();
        grace(t, 60, "вход, респавн или смена мира");
        clear();
        hasGround = false;
        bouncy = false;
        air = 0;
        hover = 0;
        attacks.clear();
    }
}
